import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
  role: z.enum(["admin", "employee"], {
    errorMap: () => ({ message: "Role must be 'admin' or 'employee'" }),
  }),
});
